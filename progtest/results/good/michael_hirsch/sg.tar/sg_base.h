/*
 * sg_base.h
 *
 * Tutorial implementation of scatter/gather with mapped memory
 *
 * Michael Hirsch
 * 2011-10-04
 */

typedef unsigned char byte;

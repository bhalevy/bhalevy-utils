All questions were compiled and tested on red hat:
>uname -a
Linux yoda 2.6.18-238.21.1IBM1.el5 #1 SMP Fri Sep 9 08:40:52 EDT 2011 x86_64 x86_64 x86_64 GNU/Linux

First question:
==============

sg_copy.h is the file you gave me. I added few things in the end for my own tests.

sg_copy.c is the c file with the implementation of the functions.

main.c is where I created a small test for these functions.

Second question:
===============

Although I wanted to rewrite the function in a clearer way, I left it as is and just pointed
out/corrected the errors, as I figured that is what you wanted me to do.
I added a small main function to the file (snippet_2.c) to test the function.

Third question:
==============

I corrected the mistake and also added some other code to test this. All in snippet_3.c.
